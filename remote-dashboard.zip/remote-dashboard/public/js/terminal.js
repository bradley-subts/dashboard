let term, fitAddon, socket;

function connectTerminal() {
  const token = sessionStorage.getItem('ws_token');
  const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
  socket = new WebSocket(`${protocol}://${window.location.host}/ws/terminal?token=${encodeURIComponent(token || '')}`);

  socket.addEventListener('open', () => {
    term.writeln('\x1b[32mConnecté au terminal du PC.\x1b[0m');
    sendResize();
  });

  socket.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === 'data') term.write(msg.data);
  });

  socket.addEventListener('close', () => {
    term.writeln('\r\n\x1b[31m[Connexion terminal fermée]\x1b[0m');
  });

  socket.addEventListener('error', () => {
    term.writeln('\r\n\x1b[31m[Erreur de connexion au terminal]\x1b[0m');
  });
}

function sendResize() {
  if (socket && socket.readyState === WebSocket.OPEN && term) {
    socket.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
  }
}

// Nouvelle fonction pour envoyer la commande complète d'un coup
function sendCustomCommand() {
  const cmdInput = document.getElementById('cmd-input');
  if (!cmdInput) return;

  const command = cmdInput.value.trim();
  
  if (command !== '' && socket && socket.readyState === WebSocket.OPEN) {
    // On envoie la commande suivie de \n (Entrée) encapsulée dans le format JSON attendu par ton serveur
    socket.send(JSON.stringify({ type: 'input', data: command + '\n' }));
    
    // On vide le champ pour la commande suivante
    cmdInput.value = '';
  }
}

function initTerminal() {
  if (term) return; // déjà initialisé
  term = new window.Terminal({
    cursorBlink: true,
    fontSize: 14,
    theme: { background: '#000000' },
    disableStdin: true // AJOUT : Empêche l'utilisateur de taper directement dans le rectangle noir
  });
  fitAddon = new window.FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(document.getElementById('terminal-container'));
  fitAddon.fit();

  // --- MODIFICATION STYLE ATERNOS ---
  // On supprime term.onData(...) qui envoyait touche par touche.
  // À la place, on gère le champ texte et le bouton :
  const cmdInput = document.getElementById('cmd-input');
  const sendBtn = document.getElementById('send-cmd-btn');

  if (cmdInput && sendBtn) {
    // Écoute le clic sur le bouton "Envoyer"
    sendBtn.addEventListener('click', sendCustomCommand);

    // Écoute la touche "Entrée" dans le champ de saisie
    cmdInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        sendCustomCommand();
      }
    });
  }
  // ----------------------------------

  window.addEventListener('resize', () => {
    fitAddon.fit();
    sendResize();
  });

  connectTerminal();
}

window.addEventListener('dashboard-ready', initTerminal);