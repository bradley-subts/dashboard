require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const http = require('http');
const { WebSocketServer } = require('ws');

const { verifyCredentials, issueToken, SESSION_DURATION } = require('./auth');
const { requireAuth } = require('./middleware/auth');
const filesRouter = require('./routes/files');
const processesRouter = require('./routes/processes');
const { attachTerminalWS } = require('./ws/terminal');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cookieParser());
app.use(express.json());

// ---- Auth ----
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Identifiant et mot de passe requis' });
  }
  try {
    if (!verifyCredentials(username, password)) {
      return res.status(401).json({ error: 'Identifiants invalides' });
    }
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  const token = issueToken(username);
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'strict',
    // secure: true, // décommente si tu sers le dashboard en HTTPS (fortement recommandé)
    maxAge: SESSION_DURATION * 1000,
  });
  res.json({ ok: true, token }); // le token est aussi renvoyé pour l'utiliser côté WebSocket
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json({ username: req.user.sub });
});

// ---- API protégées ----
app.use('/api/files', requireAuth, filesRouter);
app.use('/api/processes', requireAuth, processesRouter);

// ---- Fichiers statiques du frontend ----
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ---- Serveur HTTP + WebSocket terminal ----
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/terminal' });
attachTerminalWS(wss);

server.listen(PORT, () => {
  console.log(`Dashboard disponible sur http://localhost:${PORT}`);
});
