const express = require('express');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const multer = require('multer');

const router = express.Router();

const FILES_ROOT = path.resolve(process.cwd(), process.env.FILES_ROOT || './shared');

// S'assure que le dossier racine existe au démarrage
if (!fs.existsSync(FILES_ROOT)) {
  fs.mkdirSync(FILES_ROOT, { recursive: true });
}

// Résout un chemin "relatif" envoyé par le client et VÉRIFIE qu'il reste
// bien à l'intérieur de FILES_ROOT (protection path traversal type ../../etc)
function safeResolve(relPath) {
  const target = path.resolve(FILES_ROOT, '.' + path.sep + (relPath || ''));
  if (!target.startsWith(FILES_ROOT)) {
    throw new Error('Chemin invalide');
  }
  return target;
}

// Stockage temporaire pour multer, réécrit ensuite vers le bon dossier
const upload = multer({ dest: path.join(require('os').tmpdir(), 'dashboard-uploads') });

// Liste le contenu d'un dossier
router.get('/', async (req, res) => {
  try {
    const relPath = req.query.path || '';
    const dirPath = safeResolve(relPath);
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });

    const items = await Promise.all(entries.map(async (entry) => {
      const full = path.join(dirPath, entry.name);
      let size = null;
      let mtime = null;
      try {
        const stat = await fsp.stat(full);
        size = stat.isDirectory() ? null : stat.size;
        mtime = stat.mtime;
      } catch (_) {}
      return {
        name: entry.name,
        isDirectory: entry.isDirectory(),
        size,
        mtime,
      };
    }));

    items.sort((a, b) => {
      if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

    res.json({ path: relPath, root: FILES_ROOT, items });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Télécharge un fichier
router.get('/download', (req, res) => {
  try {
    const filePath = safeResolve(req.query.path);
    res.download(filePath);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Upload d'un ou plusieurs fichiers vers un dossier
router.post('/upload', upload.array('files'), async (req, res) => {
  try {
    const destDir = safeResolve(req.query.path || '');
    const results = [];
    for (const file of req.files || []) {
      const dest = path.join(destDir, file.originalname);
      await fsp.rename(file.path, dest);
      results.push(file.originalname);
    }
    res.json({ uploaded: results });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Crée un dossier
router.post('/mkdir', express.json(), async (req, res) => {
  try {
    const dirPath = safeResolve(path.join(req.body.path || '', req.body.name));
    await fsp.mkdir(dirPath, { recursive: false });
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Renomme un fichier ou dossier
router.post('/rename', express.json(), async (req, res) => {
  try {
    const from = safeResolve(req.body.path);
    const to = safeResolve(path.join(path.dirname(req.body.path), req.body.newName));
    await fsp.rename(from, to);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Supprime un fichier ou dossier
router.delete('/', express.json(), async (req, res) => {
  try {
    const target = safeResolve(req.body.path);
    await fsp.rm(target, { recursive: true, force: true });
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
