const url = require('url');
const os = require('os');
const pty = require('node-pty');
const { verifyToken } = require('../auth');

function defaultShell() {
  if (process.env.SHELL_PATH) return process.env.SHELL_PATH;
  return os.platform() === 'win32' ? 'powershell.exe' : (process.env.SHELL || '/bin/bash');
}

function attachTerminalWS(wss) {
  wss.on('connection', (ws, req) => {
    // Authentification : le token est passé en query string au moment du handshake
    const { query } = url.parse(req.url, true);
    const payload = verifyToken(query.token);
    if (!payload) {
      ws.close(4001, 'Non authentifié');
      return;
    }

    const shell = defaultShell();
    const ptyProcess = pty.spawn(shell, [], {
      name: 'xterm-256color',
      cols: 80,
      rows: 24,
      cwd: os.homedir(),
      env: process.env,
    });

    ptyProcess.onData((data) => {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'data', data }));
    });

    ptyProcess.onExit(() => {
      if (ws.readyState === ws.OPEN) ws.close();
    });

    ws.on('message', (msg) => {
      try {
        const parsed = JSON.parse(msg);
        if (parsed.type === 'input') {
          ptyProcess.write(parsed.data);
        } else if (parsed.type === 'resize') {
          ptyProcess.resize(parsed.cols, parsed.rows);
        }
      } catch (_) {
        // ignore messages malformés
      }
    });

    ws.on('close', () => {
      ptyProcess.kill();
    });
  });
}

module.exports = { attachTerminalWS };
