const url = require('url');
const os = require('os');
const fs = require('fs');
const pty = require('node-pty');
const { verifyToken } = require('../auth');

function defaultShell() {
  if (process.env.SHELL_PATH) return process.env.SHELL_PATH;
  return os.platform() === 'win32' ? 'powershell.exe' : (process.env.SHELL || '/bin/bash');
}

// Choisit un cwd valide : home de l'utilisateur si accessible, sinon /tmp en dernier recours
function safeCwd() {
  const home = os.homedir();
  try {
    fs.accessSync(home, fs.constants.R_OK | fs.constants.X_OK);
    return home;
  } catch (err) {
    console.error(`[terminal] home dir "${home}" inaccessible (${err.message}), fallback sur /tmp`);
    return '/tmp';
  }
}

const SCROLLBACK_MAX = 200 * 1024; // 200 Ko d'historique conservés pour les nouveaux arrivants

// ---- État du terminal partagé (un seul pty pour tout le monde) ----
let sharedPty = null;
let scrollback = '';
const clients = new Set();

function appendScrollback(data) {
  scrollback += data;
  if (scrollback.length > SCROLLBACK_MAX) {
    scrollback = scrollback.slice(scrollback.length - SCROLLBACK_MAX);
  }
}

function broadcast(payload) {
  const msg = JSON.stringify(payload);
  for (const client of clients) {
    if (client.readyState === client.OPEN) client.send(msg);
  }
}

function startSharedPty() {
  const shell = defaultShell();

  if (os.platform() !== 'win32' && !fs.existsSync(shell)) {
    console.error(`[terminal] shell introuvable: "${shell}". Vérifie SHELL_PATH dans .env`);
    return null;
  }

  let ptyProcess;
  try {
    ptyProcess = pty.spawn(shell, [], {
      name: 'xterm-256color',
      cols: 80,
      rows: 24,
      cwd: safeCwd(),
      env: process.env,
    });
  } catch (err) {
    console.error('[terminal] échec du spawn pty:', err);
    return null;
  }

  ptyProcess.onData((data) => {
    appendScrollback(data);
    broadcast({ type: 'data', data });
  });

  ptyProcess.onExit(({ exitCode, signal }) => {
    console.log(`[terminal] shell partagé terminé (code=${exitCode}, signal=${signal})`);
    broadcast({ type: 'data', data: `\r\n\x1b[33m[Shell terminé - code ${exitCode}]\x1b[0m\r\n` });
    sharedPty = null;
    scrollback = '';
  });

  return ptyProcess;
}

function getOrCreateSharedPty() {
  if (!sharedPty) {
    sharedPty = startSharedPty();
  }
  return sharedPty;
}

function attachTerminalWS(wss) {
  wss.on('connection', (ws, req) => {
    // Authentification : le token est passé en query string au moment du handshake
    const { query } = url.parse(req.url, true);
    const payload = verifyToken(query.token);
    if (!payload) {
      ws.close(4001, 'Non authentifié');
      return;
    }

    const ptyProcess = getOrCreateSharedPty();
    if (!ptyProcess) {
      ws.send(JSON.stringify({ type: 'data', data: '\r\n\x1b[31m[Erreur serveur] Impossible de démarrer le terminal partagé (voir logs serveur)\x1b[0m\r\n' }));
      ws.close(1011, 'Spawn échoué');
      return;
    }

    clients.add(ws);
    console.log(`[terminal] client connecté (${clients.size} client(s) actif(s))`);

    // Renvoie l'historique récent pour que le nouvel arrivant voie le contexte
    if (scrollback) {
      ws.send(JSON.stringify({ type: 'data', data: scrollback }));
    }
    ws.send(JSON.stringify({ type: 'data', data: `\r\n\x1b[36m[Terminal partagé - ${clients.size} utilisateur(s) connecté(s)]\x1b[0m\r\n` }));

    // Keepalive : évite que Tailscale Funnel / un proxy ne coupe une
    // connexion WebSocket jugée inactive après ~30s sans trafic.
    const keepAlive = setInterval(() => {
      if (ws.readyState === ws.OPEN) ws.ping();
    }, 15000);

    ws.on('message', (msg) => {
      if (!sharedPty) return; // le shell partagé est mort, rien à écrire
      try {
        const parsed = JSON.parse(msg);
        if (parsed.type === 'input') {
          sharedPty.write(parsed.data);
        } else if (parsed.type === 'resize') {
          // Terminal partagé : on applique le dernier redimensionnement reçu.
          // Avec plusieurs personnes connectées sur des tailles d'écran
          // différentes, l'affichage peut légèrement réajuster à chaque
          // redimensionnement de l'un des participants - c'est normal.
          sharedPty.resize(parsed.cols, parsed.rows);
        }
      } catch (err) {
        console.error('[terminal] erreur message/write:', err.message);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      clearInterval(keepAlive);
      console.log(`[terminal] client déconnecté (${clients.size} client(s) restant(s))`);
      // Le shell partagé N'EST PAS tué ici : il continue de tourner même
      // si tout le monde se déconnecte, pour retrouver son état au retour.
    });
  });
}

module.exports = { attachTerminalWS };
