import express from 'express';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';
import { Client } from 'ssh2';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// ==========================================
// CONFIGURATION DE TA FEDORA & DU SITE
// ==========================================
const MOT_DE_PASSE_SITE = "mon_super_mot_de_passe"; 

const CONFIG_SSH = {
  host: "192.168.1.231",       // IP de ta Fedora
  username: "bradley",  // Utilisateur Fedora
  password: "0565",  // Mot de passe Fedora
  port: 22
};

// ==========================================
// CLASSE SSH / SFTP ENRICHIE
// ==========================================
class ServeurDistant {
  constructor(config) {
    this.config = config;
    this.connexion = null;
  }

  connecter() {
    return new Promise((resolve, reject) => {
      this.connexion = new Client();
      this.connexion.on('ready', () => resolve());
      this.connexion.on('error', (err) => reject(err));
      this.connexion.connect(this.config);
    });
  }

  // 1. Lister le contenu d'un dossier
  listerDossier(cheminDistant) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        sftp.readdir(cheminDistant, (err, liste) => {
          if (err) return reject(err);
          const resultat = liste.map(f => {
            const estDossier = f.longname.startsWith('d');
            return { nom: f.filename, estDossier: estDossier, taille: f.attrs.size };
          });
          resolve(resultat);
        });
      });
    });
  }

  // 2. Lire le contenu d'un fichier texte
  lireFichier(cheminFichier) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        
        const stream = sftp.createReadStream(cheminFichier);
        let donnees = '';
        
        stream.on('data', (chunk) => { donnees += chunk; });
        stream.on('end', () => resolve(donnees));
        stream.on('error', (err) => reject(err));
      });
    });
  }

  // 3. Écrire/Sauvegarder un fichier texte
  ecrireFichier(cheminFichier, contenu) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        
        const stream = sftp.createWriteStream(cheminFichier);
        stream.on('close', () => resolve());
        stream.on('error', (err) => reject(err));
        
        stream.write(contenu);
        stream.end();
      });
    });
  }

  // 4. Créer un dossier
  creerDossier(cheminDossier) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        sftp.mkdir(cheminDossier, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    });
  }

  // 5. Supprimer un fichier
  supprimerFichier(cheminFichier) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        sftp.unlink(cheminFichier, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    });
  }

  // 6. Supprimer un dossier (vide)
  supprimerDossier(cheminDossier) {
    return new Promise((resolve, reject) => {
      this.connexion.sftp((err, sftp) => {
        if (err) return reject(err);
        sftp.rmdir(cheminDossier, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    });
  }
}

// Connexion SSH automatique
const ssh = new ServeurDistant(CONFIG_SSH);
ssh.connecter()
  .then(() => console.log("[SSH] Connecté avec succès au PC Fedora !"))
  .catch(err => console.error("[SSH] Échec de connexion :", err.message));

// ==========================================
// CONFIGURATION SERVEUR WEB (EXPRESS)
// ==========================================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'une_cle_secrete_aleatoire',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

function verifierAuthentification(req, res, next) {
  if (req.session && req.session.estConnecte) return next();
  res.redirect('/login');
}

// --- DOSSIER PUBLIC & PAGES ---
app.use(express.static(path.join(__dirname, 'public')));

app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.post('/login', (req, res) => {
  if (req.body.motdepasse === MOT_DE_PASSE_SITE) {
    req.session.estConnecte = true;
    res.redirect('/');
  } else {
    res.redirect('/login?error=1');
  }
});
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});
app.get('/', verifierAuthentification, (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ==========================================
// ROUTES DE L'API DE GESTION DE FICHIERS
// ==========================================

// Liste les fichiers
app.get('/api/fichiers', verifierAuthentification, async (req, res) => {
  const chemin = req.query.chemin || `/home/${CONFIG_SSH.username}`;
  try {
    const fichiers = await ssh.listerDossier(chemin);
    res.json({ succes: true, cheminActuel: chemin, fichiers });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

// Lire le contenu d'un fichier (pour l'éditeur)
app.get('/api/fichier/lire', verifierAuthentification, async (req, res) => {
  const { chemin } = req.query;
  try {
    const contenu = await ssh.lireFichier(chemin);
    res.json({ succes: true, contenu });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

// Sauvegarder un fichier
app.post('/api/fichier/sauvegarder', verifierAuthentification, async (req, res) => {
  const { chemin, contenu } = req.body;
  try {
    await ssh.ecrireFichier(chemin, contenu);
    res.json({ succes: true });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

// Créer un fichier vide
app.post('/api/fichier/creer', verifierAuthentification, async (req, res) => {
  const { chemin } = req.body;
  try {
    await ssh.ecrireFichier(chemin, ""); // On écrit un fichier vide
    res.json({ succes: true });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

// Créer un dossier
app.post('/api/dossier/creer', verifierAuthentification, async (req, res) => {
  const { chemin } = req.body;
  try {
    await ssh.creerDossier(chemin);
    res.json({ succes: true });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

// Supprimer un élément (fichier ou dossier)
app.post('/api/supprimer', verifierAuthentification, async (req, res) => {
  const { chemin, estDossier } = req.body;
  try {
    if (estDossier) {
      await ssh.supprimerDossier(chemin);
    } else {
      await ssh.supprimerFichier(chemin);
    }
    res.json({ succes: true });
  } catch (err) { res.status(500).json({ succes: false, erreur: err.message }); }
});

app.listen(PORT, () => {
  console.log(`[SERVEUR] Dashboard démarré sur http://localhost:${PORT}`);
});