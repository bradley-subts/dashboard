const url = require('url');
const os = require('os');
const fs = require('fs');
const pty = require('node-pty');
const { verifyToken } = require('../auth');

function defaultShell() {
  if (process.env.SHELL_PATH) return process.env.SHELL_PATH;
  return os.platform() === 'win32' ? 'powershell.exe' : (process.env.SHELL || '/bin/bash');
}

// Choisit un cwd valide : home de l'utilisateur si accessible, sinon /tmp en dernier recours
function safeCwd() {
  const home = os.homedir();
  try {
    fs.accessSync(home, fs.constants.R_OK | fs.constants.X_OK);
    return home;
  } catch (err) {
    console.error(`[terminal] home dir "${home}" inaccessible (${err.message}), fallback sur /tmp`);
    return '/tmp';
  }
}

function attachTerminalWS(wss) {
  wss.on('connection', (ws, req) => {
    // Authentification : le token est passé en query string au moment du handshake
    const { query } = url.parse(req.url, true);
    const payload = verifyToken(query.token);
    if (!payload) {
      ws.close(4001, 'Non authentifié');
      return;
    }

    const shell = defaultShell();

    // Vérifie que le binaire du shell existe réellement avant de spawn,
    // sinon node-pty spawn un process qui meurt instantanément et toute
    // écriture ultérieure lève "unhandled pty write error" qui plante Node.
    if (os.platform() !== 'win32' && !fs.existsSync(shell)) {
      console.error(`[terminal] shell introuvable: "${shell}". Vérifie SHELL_PATH dans .env`);
      ws.send(JSON.stringify({ type: 'data', data: `\r\n\x1b[31m[Erreur serveur] Shell introuvable: ${shell}\x1b[0m\r\n` }));
      ws.close(1011, 'Shell introuvable');
      return;
    }

    let ptyProcess;
    try {
      ptyProcess = pty.spawn(shell, [], {
        name: 'xterm-256color',
        cols: 80,
        rows: 24,
        cwd: safeCwd(),
        env: process.env,
      });
    } catch (err) {
      console.error('[terminal] échec du spawn pty:', err);
      ws.send(JSON.stringify({ type: 'data', data: `\r\n\x1b[31m[Erreur serveur] Impossible de démarrer le terminal: ${err.message}\x1b[0m\r\n` }));
      ws.close(1011, 'Spawn échoué');
      return;
    }

    let closed = false;

    ptyProcess.onData((data) => {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'data', data }));
    });

    ptyProcess.onExit(({ exitCode, signal }) => {
      closed = true;
      console.log(`[terminal] shell terminé (code=${exitCode}, signal=${signal})`);
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ type: 'data', data: `\r\n\x1b[33m[Shell terminé - code ${exitCode}]\x1b[0m\r\n` }));
        ws.close();
      }
    });

    ws.on('message', (msg) => {
      if (closed) return; // évite d'écrire sur un pty déjà mort
      try {
        const parsed = JSON.parse(msg);
        if (parsed.type === 'input') {
          ptyProcess.write(parsed.data);
        } else if (parsed.type === 'resize') {
          ptyProcess.resize(parsed.cols, parsed.rows);
        }
      } catch (err) {
        // Capture aussi les erreurs d'écriture pty (ex: EIO sur pty fermé)
        // pour ne JAMAIS laisser planter tout le process Node.
        console.error('[terminal] erreur message/write:', err.message);
      }
    });

    ws.on('close', () => {
      closed = true;
      try {
        ptyProcess.kill();
      } catch (_) {
        // process déjà mort, rien à faire
      }
    });
  });
}

module.exports = { attachTerminalWS };
