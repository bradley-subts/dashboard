const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
const SESSION_DURATION = parseInt(process.env.SESSION_DURATION || '28800', 10);

if (!JWT_SECRET || JWT_SECRET === 'change-this-to-a-long-random-string') {
  console.warn('[SECURITY] JWT_SECRET non configuré ou par défaut. Change-le dans .env avant toute utilisation réelle !');
}

function verifyCredentials(username, password) {
  const expectedUser = process.env.ADMIN_USER;
  const expectedHash = process.env.ADMIN_PASS_HASH;

  if (!expectedUser || !expectedHash) {
    throw new Error('ADMIN_USER / ADMIN_PASS_HASH non configurés dans .env');
  }

  if (username !== expectedUser) return false;
  return bcrypt.compareSync(password, expectedHash);
}

function issueToken(username) {
  return jwt.sign({ sub: username }, JWT_SECRET, { expiresIn: SESSION_DURATION });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

module.exports = { verifyCredentials, issueToken, verifyToken, SESSION_DURATION };
