const { verifyToken } = require('../auth');

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.token;
  if (!token) {
    return res.status(401).json({ error: 'Non authentifié' });
  }
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Session invalide ou expirée' });
  }
  req.user = payload;
  next();
}

module.exports = { requireAuth };
