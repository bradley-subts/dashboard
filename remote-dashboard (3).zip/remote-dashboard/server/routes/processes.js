const express = require('express');
const si = require('systeminformation');

const router = express.Router();

// Liste tous les processus en cours avec CPU/RAM
router.get('/', async (req, res) => {
  try {
    const data = await si.processes();
    const list = data.list
      .map(p => ({
        pid: p.pid,
        name: p.name,
        cpu: Number(p.cpu.toFixed(1)),
        mem: Number(p.mem.toFixed(1)),
        state: p.state,
        started: p.started,
      }))
      .sort((a, b) => b.cpu - a.cpu);

    res.json({
      summary: {
        all: data.all,
        running: data.running,
        sleeping: data.sleeping,
      },
      list,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Tue un processus par PID
router.delete('/:pid', (req, res) => {
  const pid = parseInt(req.params.pid, 10);
  if (!pid || pid === process.pid) {
    return res.status(400).json({ error: 'PID invalide' });
  }
  try {
    process.kill(pid, req.query.force === 'true' ? 'SIGKILL' : 'SIGTERM');
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
