let currentPath = '';

function fmtSize(bytes) {
  if (bytes === null || bytes === undefined) return '—';
  const units = ['o', 'Ko', 'Mo', 'Go'];
  let i = 0, val = bytes;
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++; }
  return `${val.toFixed(val < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function fmtDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString();
}

async function loadFiles(relPath) {
  currentPath = relPath || '';
  const res = await fetch(`/api/files?path=${encodeURIComponent(currentPath)}`);
  const data = await res.json();
  document.getElementById('files-path').textContent = '/' + currentPath;

  const tbody = document.getElementById('files-list');
  tbody.innerHTML = '';

  if (!res.ok) {
    tbody.innerHTML = `<tr><td colspan="5">Erreur : ${data.error}</td></tr>`;
    return;
  }

  for (const item of data.items) {
    const tr = document.createElement('tr');
    const itemPath = currentPath ? `${currentPath}/${item.name}` : item.name;

    tr.innerHTML = `
      <td class="row-icon">${item.isDirectory ? '📁' : '📄'}</td>
      <td>${item.isDirectory
        ? `<button class="link-btn" data-open="${itemPath}">${item.name}</button>`
        : item.name}</td>
      <td>${fmtSize(item.size)}</td>
      <td>${fmtDate(item.mtime)}</td>
      <td>
        ${!item.isDirectory ? `<button class="link-btn" data-edit="${itemPath}" data-editname="${item.name}">📝</button>` : ''}
        ${!item.isDirectory ? `<button class="link-btn" data-download="${itemPath}">⬇️</button>` : ''}
        <button class="link-btn" data-rename="${itemPath}" data-name="${item.name}">✏️</button>
        <button class="link-btn danger-btn" data-delete="${itemPath}">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll('[data-open]').forEach(btn =>
    btn.addEventListener('click', () => loadFiles(btn.dataset.open)));

  tbody.querySelectorAll('[data-edit]').forEach(btn =>
    btn.addEventListener('click', () => openEditor(btn.dataset.edit, btn.dataset.editname)));

  tbody.querySelectorAll('[data-download]').forEach(btn =>
    btn.addEventListener('click', () => {
      window.open(`/api/files/download?path=${encodeURIComponent(btn.dataset.download)}`, '_blank');
    }));

  tbody.querySelectorAll('[data-rename]').forEach(btn =>
    btn.addEventListener('click', async () => {
      const newName = prompt('Nouveau nom :', btn.dataset.name);
      if (!newName || newName === btn.dataset.name) return;
      await fetch('/api/files/rename', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: btn.dataset.rename, newName }),
      });
      loadFiles(currentPath);
    }));

  tbody.querySelectorAll('[data-delete]').forEach(btn =>
    btn.addEventListener('click', async () => {
      if (!confirm('Supprimer définitivement cet élément ?')) return;
      await fetch('/api/files', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: btn.dataset.delete }),
      });
      loadFiles(currentPath);
    }));
}

document.getElementById('files-up').addEventListener('click', () => {
  if (!currentPath) return;
  const parent = currentPath.split('/').slice(0, -1).join('/');
  loadFiles(parent);
});

document.getElementById('files-mkdir').addEventListener('click', async () => {
  const name = prompt('Nom du nouveau dossier :');
  if (!name) return;
  const res = await fetch('/api/files/mkdir', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: currentPath, name }),
  });
  const data = await res.json();
  if (!res.ok) alert(data.error);
  loadFiles(currentPath);
});

document.getElementById('files-new-file').addEventListener('click', async () => {
  const name = prompt('Nom du nouveau fichier :');
  if (!name) return;
  const res = await fetch('/api/files/create', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: currentPath, name }),
  });
  const data = await res.json();
  if (!res.ok) {
    alert(data.error);
    return;
  }
  await loadFiles(currentPath);
  openEditor(currentPath ? `${currentPath}/${name}` : name, name);
});

document.getElementById('files-upload-input').addEventListener('change', async (e) => {
  const files = e.target.files;
  if (!files.length) return;
  const formData = new FormData();
  for (const f of files) formData.append('files', f);
  const res = await fetch(`/api/files/upload?path=${encodeURIComponent(currentPath)}`, {
    method: 'POST',
    body: formData,
  });
  const data = await res.json();
  if (!res.ok) alert(data.error);
  e.target.value = '';
  loadFiles(currentPath);
});

// ---- Éditeur de texte ----
let editingPath = null;

const editorOverlay = document.getElementById('editor-overlay');
const editorTextarea = document.getElementById('editor-textarea');
const editorFilename = document.getElementById('editor-filename');
const editorStatus = document.getElementById('editor-status');

async function openEditor(filePath, fileName) {
  editorStatus.textContent = 'Chargement...';
  editorFilename.textContent = '/' + filePath;
  editorTextarea.value = '';
  editorOverlay.classList.remove('hidden');

  try {
    const res = await fetch(`/api/files/content?path=${encodeURIComponent(filePath)}`);
    const data = await res.json();
    if (!res.ok) {
      editorStatus.textContent = `Erreur : ${data.error}`;
      return;
    }
    editingPath = filePath;
    editorTextarea.value = data.content;
    editorStatus.textContent = '';
    editorTextarea.focus();
  } catch (err) {
    editorStatus.textContent = 'Erreur de chargement du fichier';
  }
}

async function saveEditor() {
  if (!editingPath) return;
  editorStatus.textContent = 'Enregistrement...';
  try {
    const res = await fetch('/api/files/content', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: editingPath, content: editorTextarea.value }),
    });
    const data = await res.json();
    if (!res.ok) {
      editorStatus.textContent = `Erreur : ${data.error}`;
      return;
    }
    editorStatus.textContent = 'Enregistré ✅';
    loadFiles(currentPath);
  } catch (err) {
    editorStatus.textContent = 'Erreur lors de l\'enregistrement';
  }
}

function closeEditor() {
  editorOverlay.classList.add('hidden');
  editingPath = null;
  editorTextarea.value = '';
}

document.getElementById('editor-save').addEventListener('click', saveEditor);
document.getElementById('editor-close').addEventListener('click', closeEditor);

// Ctrl+S dans l'éditeur = enregistrer, sans déclencher la sauvegarde de page du navigateur
editorTextarea.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    saveEditor();
  }
});

window.addEventListener('tab-shown', (e) => {
  if (e.detail === 'files') loadFiles(currentPath);
});
window.addEventListener('dashboard-ready', () => loadFiles(''));
