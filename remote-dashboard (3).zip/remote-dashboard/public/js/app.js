// Vérifie que l'utilisateur est bien connecté, sinon redirige vers login
async function checkAuth() {
  const res = await fetch('/api/me');
  if (!res.ok) {
    window.location.href = '/login.html';
    return null;
  }
  const data = await res.json();
  document.getElementById('whoami').textContent = data.username;
  return data;
}

function initTabs() {
  const buttons = document.querySelectorAll('.tab-btn');
  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
      window.dispatchEvent(new CustomEvent('tab-shown', { detail: btn.dataset.tab }));
    });
  });
}

document.getElementById('logout-btn').addEventListener('click', async () => {
  await fetch('/api/logout', { method: 'POST' });
  sessionStorage.removeItem('ws_token');
  window.location.href = '/login.html';
});

(async () => {
  const user = await checkAuth();
  if (!user) return;
  initTabs();
  window.dispatchEvent(new CustomEvent('dashboard-ready'));
})();
