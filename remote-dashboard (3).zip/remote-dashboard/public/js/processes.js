async function loadProcesses() {
  const res = await fetch('/api/processes');
  const data = await res.json();
  const tbody = document.getElementById('proc-list');
  tbody.innerHTML = '';

  if (!res.ok) {
    tbody.innerHTML = `<tr><td colspan="6">Erreur : ${data.error}</td></tr>`;
    return;
  }

  document.getElementById('proc-summary').textContent =
    `${data.summary.all} processus • ${data.summary.running} actifs • ${data.summary.sleeping} en veille`;

  for (const p of data.list.slice(0, 200)) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.pid}</td>
      <td>${p.name}</td>
      <td>${p.cpu}</td>
      <td>${p.mem}</td>
      <td>${p.state}</td>
      <td><button class="link-btn danger-btn" data-kill="${p.pid}">Arrêter</button></td>
    `;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll('[data-kill]').forEach(btn =>
    btn.addEventListener('click', async () => {
      if (!confirm(`Arrêter le processus ${btn.dataset.kill} ?`)) return;
      const res = await fetch(`/api/processes/${btn.dataset.kill}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) alert(data.error);
      loadProcesses();
    }));
}

document.getElementById('proc-refresh').addEventListener('click', loadProcesses);

window.addEventListener('tab-shown', (e) => {
  if (e.detail === 'processes') loadProcesses();
});
