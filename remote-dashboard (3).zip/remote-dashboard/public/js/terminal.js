let term, fitAddon, socket;

function connectTerminal() {
  const token = sessionStorage.getItem('ws_token');
  const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
  socket = new WebSocket(`${protocol}://${window.location.host}/ws/terminal?token=${encodeURIComponent(token || '')}`);

  socket.addEventListener('open', () => {
    term.writeln('\x1b[32mConnecté au terminal du PC.\x1b[0m');
    sendResize();
  });

  socket.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === 'data') term.write(msg.data);
  });

  socket.addEventListener('close', () => {
    term.writeln('\r\n\x1b[31m[Connexion terminal fermée]\x1b[0m');
  });

  socket.addEventListener('error', () => {
    term.writeln('\r\n\x1b[31m[Erreur de connexion au terminal]\x1b[0m');
  });
}

function sendResize() {
  if (socket && socket.readyState === WebSocket.OPEN && term) {
    socket.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
  }
}

function initTerminal() {
  if (term) return; // déjà initialisé
  term = new window.Terminal({
    cursorBlink: true,
    fontSize: 14,
    theme: { background: '#000000' },
  });
  fitAddon = new window.FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(document.getElementById('terminal-container'));
  fitAddon.fit();

  term.onData((data) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ type: 'input', data }));
    }
  });

  window.addEventListener('resize', () => {
    fitAddon.fit();
    sendResize();
  });

  connectTerminal();
}

window.addEventListener('dashboard-ready', initTerminal);
