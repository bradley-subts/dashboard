// Génère un hash bcrypt à partir d'un mot de passe donné en argument.
// Usage : npm run genhash -- "MonMotDePasse"
const bcrypt = require('bcryptjs');

const password = process.argv[2];

if (!password) {
  console.error('Usage: npm run genhash -- "TonMotDePasse"');
  process.exit(1);
}

const hash = bcrypt.hashSync(password, 12);
console.log('\nAjoute cette ligne dans ton fichier .env :\n');
console.log(`ADMIN_PASS_HASH=${hash}\n`);
