# Remote Dashboard

Dashboard de contrôle à distance pour ton PC, avec :
- **Login** sécurisé (JWT + cookie httpOnly + mot de passe hashé bcrypt)
- **Terminal** web temps réel (vrai pseudo-terminal via `node-pty`, comme un SSH mais en local)
- **Gestionnaire de fichiers** (parcourir, uploader, télécharger, renommer, supprimer)
- **Gestionnaire de processus** (liste CPU/RAM en direct, arrêt de processus)

## 1. Installation

```bash
cd remote-dashboard
npm install
```

> `node-pty` compile un module natif. Si l'installation échoue :
> - **Linux** : `sudo apt install build-essential python3`
> - **macOS** : `xcode-select --install`
> - **Windows** : installe les "Build Tools for Visual Studio" (ou `npm install --global windows-build-tools` en admin)

## 2. Configuration

```bash
cp .env.example .env
```

Génère le hash de ton mot de passe :

```bash
npm run genhash -- "TonMotDePasseSolide"
```

Copie la ligne `ADMIN_PASS_HASH=...` affichée dans ton `.env`, puis complète :
- `ADMIN_USER` : ton identifiant
- `JWT_SECRET` : une longue chaîne aléatoire (ex: `openssl rand -hex 32`)
- `FILES_ROOT` : le dossier que le gestionnaire de fichiers pourra parcourir (par défaut `./shared`, **volontairement limité** — ne pas mettre `/` ou `C:\` sans réfléchir)

## 3. Lancer le dashboard

```bash
npm start
```

Le dashboard est accessible sur `http://localhost:3000` (ou l'IP de ton PC sur le réseau local, ex: `http://192.168.1.X:3000`).

## 4. Accès à distance (hors réseau local) — ⚠️ lis bien cette partie

Ce dashboard donne un accès **total** à ton PC (terminal = exécution de n'importe quelle commande). L'exposer directement sur Internet est risqué. Recommandations sérieuses :

1. **Ne jamais exposer le port 3000 directement sur Internet** via redirection de port simple.
2. Utilise plutôt un tunnel/VPN pour t'y connecter depuis l'extérieur :
   - **Tailscale** ou **WireGuard** (VPN privé, simple à mettre en place) — solution la plus sûre.
   - Ou un reverse proxy (Nginx/Caddy) devant l'app, avec **HTTPS obligatoire** (Let's Encrypt) et idéalement une authentification supplémentaire (Basic Auth, ou liste blanche d'IP).
3. Si tu passes en HTTPS, décommente `secure: true` sur le cookie dans `server/index.js`.
4. Mets un mot de passe fort et un `JWT_SECRET` unique et long.
5. Le fichier `.env` ne doit **jamais** être commité dans un dépôt Git (déjà exclu via `.gitignore`).

## Structure du projet

```
remote-dashboard/
  server/
    index.js          → serveur Express + WebSocket
    auth.js            → login / JWT
    middleware/auth.js → protection des routes
    routes/files.js    → API gestionnaire de fichiers
    routes/processes.js→ API gestionnaire de processus
    ws/terminal.js      → WebSocket terminal (node-pty)
  public/
    login.html
    index.html
    css/style.css
    js/app.js, terminal.js, files.js, processes.js
  scripts/gen-hash.js  → génère le hash bcrypt du mot de passe
```

## Personnalisation possible

- Multi-utilisateurs : remplace le check `ADMIN_USER`/`ADMIN_PASS_HASH` par une vraie base d'utilisateurs.
- Historique/logs des commandes tapées dans le terminal.
- Notifications (RAM/CPU élevés, nouveau fichier, etc.).
